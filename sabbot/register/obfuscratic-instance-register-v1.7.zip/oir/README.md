# Obfuscratic Instance Register — working bundle v1.1

Two additions to the Obfuscratic Asymmetry instrument, built to the discipline the book already states rather than around it.

**Read `PROVENANCE.md` first.** It says which files are the analyst's material and which are Claude-generated and unverified. Nothing in this bundle supplies an evidence anchor.

---

## What this is

The instrument scores **architectures** — seven of them, slowly, against a fixed slate. That layer should not grow by absorbing salient cases; Part IV says so, and the breadth guard here enforces it.

The **instance layer** is the new object. It holds dated events drawn from enumerable, content-blind frames. Each event carries a direction sign and no score. It can hold thousands of items and produces one statistic: whether the direction of divergence between stated beneficiary and realized incidence departs from symmetry across independent decision loci.

The null is the book's own concession — ordinary failure is symmetric, keeps no direction — which makes a corpus of ordinary administrative output the right place to run the test rather than the wrong one.

## Layout

```
PRE-REGISTRATION.md    frames, null, unit of analysis, reportability table, liabilities
PROVENANCE.md          what is the analyst's and what is Claude's
schema/                instance, frame and architecture schemas; the coding manual
frames/                four drafted frames, all status: draft, awaiting lock
register/              transcribed architecture scores, the slate, the onset series
adversarial/           T1 convict-a-friend, T2 acquit-an-enemy, scoring worksheet
annex/                 evidence-annex.json — 14 verified items, sourced and tagged
pipeline/              the statistics, and the pipeline self-test
render/                payload.json, nullcheck.json, index.html
```

No synthetic data ships in this bundle. `register/instances.jsonl` is empty because no frame is
locked and coding has not begun; the direction layer correctly reports that nothing is
reportable. `pipeline/nullcheck.py` generates its own corpora in memory as a SELF-TEST of the
estimator — it is a unit test, never a finding, and its output does not appear on the page.

## Run it

```bash
python3 pipeline/nullcheck.py        # self-test of the estimator; read before trusting a p
python3 pipeline/run_all.py          # writes render/payload.json
python3 pipeline/direction_test.py register/instances.jsonl
python3 pipeline/synchrony.py  register/onsets.json
python3 pipeline/breadth.py    register/architectures.json register/slate.json
```

No dependencies beyond the standard library. `numpy` is used for the permutation Monte Carlo when present and the pure-Python path is equivalent.

## The three rules the code enforces rather than recommends

1. **Unratified records do not enter statistics or figures.** No override.
2. **Breadth refuses to compute over a grown denominator.** It returns a frame violation naming the intruding architectures.
3. **Synchrony refuses to report a p below six matched baselines**, because a rank-based p cannot fall under 1/(B+1) and three baselines floor it at 0.25.

## Frame enumeration, executed 2026-09-12

| Frame | Status | Population |
|---|---|---|
| `FRM-FR-FINALRULES-2025H2` | enumerated | 1,272 final rules (2,441 for calendar 2025) |
| `FRM-OIG-2025` | reachable, date parameters not captured | 35,963 unfiltered |
| `FRM-GAO-2025` | blocked by robots.txt; route via GovInfo instead | not recorded |
| `FRM-USASPENDING-TERM-2025` | needs one POST | not recorded |
| `FRM-SCOTUS-EMERGENCY-2025-2026` | drafted this session | not recorded |

Each frame file records what was attempted, what returned, and the exact step that closes it.
Nothing is asserted as a count that was not returned by the source.

## Before coding a single real instance

- Lock each frame: run the enumeration once, record the population size, fix the sampling *n* where sampling applies, and write your own direction-share prediction and falsification trigger.
- Lock the slate: four members currently carry no band prediction.
- Lock the two adversarial predictions in your own words. The drafts in `adversarial/` are Claude's and carry no evidentiary weight.
