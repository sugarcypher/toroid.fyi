"""
Candidate ingest with provenance stamping and a human ratification queue.

The rule this module enforces: a machine may PROPOSE a record. It may not CODE
one. A machine-proposed field that a human ratified without opening the primary
source is unsourced material wearing a human signature, so ratification is
per-field and the fields the human changed are recorded. The running alteration
rate is the register's measured machine error rate and is published with the
statistics rather than kept internally.

Nothing here fetches or invents sources. Candidates arrive from an enumeration of
a locked frame; this module stamps, queues, validates and gates them.
"""

from __future__ import annotations

import json
import os
import sys
from collections import defaultdict
from datetime import date

MACHINE_UNSETTABLE = {
    # Fields a machine proposal may never populate: each requires reading the
    # primary document, and a plausible guess in any of them is the exact failure
    # the provenance rule exists to catch.
    "direction",
    "direction_rationale",
    "locus_id",
    "locus_rationale",
    "payoff_conjunction",
    "coded_by",
    "second_coder",
    "second_coder_direction",
}

REQUIRED_AT_RATIFICATION = [
    "frame_id", "frame_position", "source_ref", "event_date", "locus_id",
    "locus_rationale", "stated_beneficiary_class", "stated_beneficiary_quote",
    "realized_incidence_class", "incidence_basis", "direction",
    "direction_rationale", "evidence_tag", "coded_by",
]


def _serial(existing):
    used = {r["instance_id"] for r in existing if "instance_id" in r}
    n = 0
    while True:
        n += 1
        cand = f"OIR-{date.today().year}-{n:06d}"
        if cand not in used:
            return cand


def stamp_candidates(candidates, frame_id, agent_id, existing=None):
    """Turn raw enumerated items into queued, unratified, provenance-stamped records."""
    existing = existing or []
    out = []
    for i, c in enumerate(candidates, start=1):
        rec = {k: v for k, v in c.items() if k not in MACHINE_UNSETTABLE}
        stripped = sorted(set(c) & MACHINE_UNSETTABLE)
        rec["instance_id"] = _serial(existing + out)
        rec["frame_id"] = frame_id
        rec.setdefault("frame_position", i)
        rec["direction"] = 0
        rec["evidence_tag"] = rec.get("evidence_tag", "contested")
        rec["incidence_basis"] = "not_yet_established"
        rec["coded_by"] = ""
        rec["provenance"] = {
            "proposed_by": "machine_extraction",
            "proposing_agent": agent_id,
            "ratified": False,
            "machine_fields_altered_at_ratification": [],
        }
        if stripped:
            rec["notes"] = (
                (rec.get("notes", "") + " ").strip()
                + f"[ingest] Machine-supplied values for {stripped} were discarded; "
                  "these fields require the primary document."
            ).strip()
        out.append(rec)
    return out


def ratify(record, human_id, field_updates, today=None):
    """
    Apply a human's per-field ratification. Records which machine-proposed values
    the human changed, then gates on the required-field list.
    """
    today = today or date.today().isoformat()
    prov = record.setdefault("provenance", {})
    altered = set(prov.get("machine_fields_altered_at_ratification", []))
    for k, v in field_updates.items():
        if k in record and record[k] not in (None, "", 0, []) and record[k] != v:
            altered.add(k)
        elif k not in record and prov.get("proposed_by") == "machine_extraction":
            pass
        record[k] = v
    record["coded_by"] = field_updates.get("coded_by", human_id)
    record["coded_on"] = today

    missing = [f for f in REQUIRED_AT_RATIFICATION
               if record.get(f) in (None, "", [])]
    if "direction" in missing:
        missing.remove("direction")   # 0 is a legal coded value
    if missing:
        prov["ratified"] = False
        return record, f"NOT RATIFIED. Missing required fields: {missing}"

    if record.get("incidence_basis") == "not_yet_established" and record.get("direction") != 0:
        prov["ratified"] = False
        return record, ("NOT RATIFIED. incidence_basis is not_yet_established, which "
                        "forces direction to 0. Establish incidence or code 0.")

    prov["ratified"] = True
    prov["ratified_by"] = human_id
    prov["ratified_on"] = today
    prov["machine_fields_altered_at_ratification"] = sorted(altered)
    return record, "RATIFIED"


def alteration_report(rows):
    """Published machine error rate: how often a human had to change a proposal."""
    machine = [r for r in rows
               if r.get("provenance", {}).get("proposed_by") == "machine_extraction"
               and r.get("provenance", {}).get("ratified")]
    if not machine:
        return {"machine_proposed_ratified": 0,
                "note": "No ratified machine-proposed records yet."}
    per_field = defaultdict(int)
    any_alt = 0
    for r in machine:
        alt = r["provenance"].get("machine_fields_altered_at_ratification", [])
        if alt:
            any_alt += 1
        for f in alt:
            per_field[f] += 1
    return {
        "machine_proposed_ratified": len(machine),
        "records_altered_by_human": any_alt,
        "alteration_rate": round(any_alt / len(machine), 4),
        "per_field_alteration_counts": dict(sorted(per_field.items(),
                                                   key=lambda kv: -kv[1])),
        "note": ("This is the register's measured machine-extraction error rate. It is "
                 "published beside the statistics. A rate near zero on a large batch is "
                 "more likely to mean ratification without reading than a reliable "
                 "extractor."),
    }


def queue_status(rows):
    r = defaultdict(int)
    for row in rows:
        p = row.get("provenance", {})
        key = ("ratified" if p.get("ratified") else "awaiting_ratification")
        r[f"{p.get('proposed_by','unknown')}__{key}"] += 1
    return dict(r)


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "register/instances.jsonl"
    rows = [json.loads(l) for l in open(path) if l.strip()]
    print(json.dumps({"queue": queue_status(rows),
                      "alteration": alteration_report(rows)}, indent=2))
