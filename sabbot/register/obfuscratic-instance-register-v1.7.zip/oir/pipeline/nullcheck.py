"""
Null-behaviour verification. The instrument has to be able to lose, and this is
where that is demonstrated rather than asserted.

Four synthetic corpora, none of them evidence about anything:

  A  directionless, one instance per locus      -> cluster test must NOT fire
  B  directionless at locus level, 25 items per
     locus, all items inside a locus agreeing   -> naive test fires hard,
                                                   cluster test must NOT fire
  C  genuinely directional across many loci     -> cluster test should fire
  D  3,000 items, all one direction, ALL IN ONE
     LOCUS  ("thousands of headlines about one
     bill")                                     -> naive p astronomical,
                                                   effective n = 1, nothing reportable

B and D are the load-bearing cases. They are the two ways a large corpus produces
a spectacular p-value while containing almost no information.
"""

from __future__ import annotations

import json
import os
import random
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import direction_test  # noqa: E402
from direction_test import run  # noqa: E402

# Calibration needs many replications, so each replication uses fewer permutation
# draws. 4,000 draws resolves a 0.05 rejection boundary adequately for a
# rejection-rate estimate and is not used for any published p-value.
direction_test.DEFAULT_DRAWS = 4000


def _rec(i, locus, direction):
    return {
        "instance_id": f"OIR-2026-{i:06d}",
        "frame_id": "FRM-SYNTHETIC",
        "frame_position": i,
        "source_ref": {"citation": "synthetic", "url": "https://example.invalid/synthetic",
                       "retrieved_on": "2026-09-12"},
        "event_date": "2026-01-15",
        "locus_id": locus,
        "locus_rationale": "synthetic",
        "stated_beneficiary_class": "general_public",
        "realized_incidence_class": "large_incumbent_firms",
        "incidence_basis": "third_party_measurement",
        "direction": direction,
        "evidence_tag": "occurred",
        "payoff_conjunction": True,
        "coded_by": "synthetic",
        "coded_on": "2026-09-12",
        "provenance": {"proposed_by": "human", "ratified": True},
    }


def corpus(spec, seed):
    rng = random.Random(seed)
    rows, i = [], 0
    for locus, n, mode in spec:
        s = rng.choice([1, -1]) if mode == "locus_random" else None
        for _ in range(n):
            i += 1
            if mode == "iid_random":
                d = rng.choice([1, -1])
            elif mode == "locus_random":
                d = s
            elif mode == "directional":
                d = 1 if rng.random() < 0.72 else -1
            else:
                d = 1
            rows.append(_rec(i, locus, d))
    return rows


def write(rows):
    fh = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False)
    for r in rows:
        fh.write(json.dumps(r) + "\n")
    fh.close()
    return fh.name


SCENARIOS = {
    "A_directionless_independent": (
        [(f"L{k:03d}", 1, "iid_random") for k in range(400)],
        "Cluster test must not fire. 400 independent loci, no direction.",
    ),
    "B_directionless_but_clustered": (
        [(f"L{k:03d}", 25, "locus_random") for k in range(40)],
        "1,000 items, 40 loci, direction random AT THE LOCUS LEVEL. The naive "
        "per-instance test fires hard on pure noise; the cluster test must not.",
    ),
    "C_genuinely_directional": (
        [(f"L{k:03d}", 3, "directional") for k in range(60)],
        "60 loci, roughly 72 percent positive. The cluster test should fire.",
    ),
    "D_one_locus_three_thousand_items": (
        [("L000", 3000, "all_positive")],
        "3,000 items all pointing one way, all from ONE decision locus. "
        "Effective n = 1. Nothing is reportable.",
    ),
}


REPLICATIONS = 400


def _one(spec, seed):
    path = write(corpus(spec, seed=seed))
    try:
        return run(path)
    finally:
        os.unlink(path)


def main(replications=REPLICATIONS):
    """
    Calibration over repeated draws, not a single run.

    A single draw proves nothing: a correctly calibrated test rejects a true null
    5 percent of the time, so one null replication showing p < 0.05 is the test
    working. What proves calibration is the REJECTION RATE across many draws.

    For the two null scenarios the cluster test should reject at about 0.05.
    The per-instance test should reject at about 0.05 in A, where instances are
    independent, and at close to 1.0 in B, where they are not. That gap is the
    whole argument for the locus rule.
    """
    out = {"replications": replications, "alpha": 0.05, "scenarios": {}}
    for name, (spec, expect) in SCENARIOS.items():
        cl, nv, effn, means = [], [], [], []
        reps = 1 if name.startswith("D_") else replications  # D is deterministic
        for i in range(reps):
            r = _one(spec, seed=1_000_000 + i * 7919 + (hash(name) % 9973))
            cl.append(r.p_cluster_two_sided)
            nv.append(r.p_instance_level_INVALID)
            effn.append(r.effective_n)
            means.append(r.observed_mean_of_locus_means)
        k = len(cl)
        out["scenarios"][name] = {
            "expectation": expect,
            "replications_run": k,
            "effective_n": effn[0],
            "cluster_test_rejection_rate_at_0.05": round(sum(1 for p in cl if p < 0.05) / k, 4),
            "cluster_test_median_p": round(sorted(cl)[k // 2], 6),
            "per_instance_test_rejection_rate_at_0.05_INVALID":
                round(sum(1 for p in nv if p < 0.05) / k, 4),
            "per_instance_test_median_p_INVALID": (
                f"{sorted(nv)[k // 2]:.3e}" if sorted(nv)[k // 2] < 1e-4
                else round(sorted(nv)[k // 2], 6)),
            "median_observed_mean_of_locus_means": round(sorted(means)[k // 2], 4),
        }
    # verdicts, computed rather than asserted
    v = []
    a = out["scenarios"]["A_directionless_independent"]
    b = out["scenarios"]["B_directionless_but_clustered"]
    c = out["scenarios"]["C_genuinely_directional"]
    d = out["scenarios"]["D_one_locus_three_thousand_items"]
    import math as _m
    k = out["replications"]
    se = _m.sqrt(0.05 * 0.95 / k)
    lo, hi = 0.05 - 2.58 * se, 0.05 + 2.58 * se
    ar = a["cluster_test_rejection_rate_at_0.05"]
    v.append(
        f"A: on independent data the cluster test rejects a true null at {ar:.3f}. "
        f"Nominal is 0.05; with {k} replications the 99 percent band is "
        f"[{max(0.0, lo):.3f}, {hi:.3f}]. "
        + ("Inside the band: calibrated."
           if lo <= ar <= hi else
           "OUTSIDE the band. Do not publish a p from this pipeline until the "
           "discrepancy is explained; an uncalibrated null is the one defect that "
           "invalidates every downstream number."))
    v.append(
        f"B: on data with NO direction at the locus level, the per-instance test rejects "
        f"{b['per_instance_test_rejection_rate_at_0.05_INVALID']:.0%} of the time and the "
        f"cluster test {b['cluster_test_rejection_rate_at_0.05']:.0%}. The per-instance "
        "figure is the inflation the locus rule exists to remove; it is pure noise "
        "reported as certainty.")
    v.append(
        f"C: on genuinely directional data the cluster test rejects "
        f"{c['cluster_test_rejection_rate_at_0.05']:.0%} of the time. The test has power, "
        "so a null result on real data is informative rather than merely weak.")
    v.append(
        f"D: 3,000 items all pointing one way from ONE decision locus. Effective n = "
        f"{d['effective_n']}. Cluster p = {d['cluster_test_median_p']}. Per-instance p "
        f"underflows double precision. This is the shape of a large corpus that contains "
        "one fact, and it is the failure mode the locus rule was written for.")
    out["verdicts"] = v
    print(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    main()
