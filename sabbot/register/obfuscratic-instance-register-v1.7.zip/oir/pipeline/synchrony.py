"""
Onset-dispersion synchrony, in excess-over-matched-baseline form only.

Part IV is explicit: a single common driver (an administration taking office and
changing many policies at once) produces high synchrony with no covert
coordination at all. So the bare index diagnoses nothing and is refused here.
What is reportable is the EXCESS of observed onset bunching over the bunching
produced by matched prior transitions of comparable scope.

The hard limit, stated by the tool rather than buried: with B matched baseline
transitions, a rank-based p cannot fall below 1/(B+1). Three baselines floor it
at 0.25. This module refuses to emit a p below six baselines and says so.
"""

from __future__ import annotations

import json
import statistics
from dataclasses import dataclass, field, asdict

MIN_BASELINES_FOR_P = 6
MIN_ONSETS = 4


@dataclass
class SynchronyResult:
    reportable: bool
    reason: str
    n_onsets: int
    observed_dispersion_quarters: float | None = None
    baselines: list = field(default_factory=list)
    rank_of_observed: int | None = None
    p_rank_based: float | None = None
    p_floor_at_this_baseline_count: float | None = None
    excess_vs_baseline_median: float | None = None
    persistence: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)


def _q(epoch: str) -> int:
    y, q = epoch.split("-Q")
    return int(y) * 4 + (int(q) - 1)


def _dispersion(onsets):
    """Population SD of onset quarters. Lower means more bunched."""
    if len(onsets) < 2:
        return 0.0
    return statistics.pstdev(onsets)


def _persistence(onsets, transition_q, tail_quarters=4):
    """
    Discriminator 1 from Part IV: do onsets cluster only at the transition, or
    keep rolling at an elevated rate well after it?
    """
    at = [o for o in onsets if 0 <= o - transition_q <= tail_quarters]
    after = [o for o in onsets if o - transition_q > tail_quarters]
    before = [o for o in onsets if o < transition_q]
    return {
        "onsets_before_transition": len(before),
        "onsets_within_transition_window": len(at),
        "onsets_after_transition_window": len(after),
        "post_window_rate_per_quarter": (
            round(len(after) / max(1, max(onsets) - (transition_q + tail_quarters)), 3)
            if after else 0.0
        ),
        "reading": (
            "Onsets continue past the transition window; a one-time transition does "
            "not account for the tail."
            if len(after) > len(at)
            else "Onsets concentrate in the transition window; ordinary fast regime "
                 "change accounts for this pattern without anything stronger."
        ),
    }


def run(onsets_path):
    """
    Input JSON:
    {
      "observed": {"transition_epoch": "2025-Q1",
                   "onsets": {"arch_id": "2025-Q3", ...}},
      "baselines": [{"label": "Reagan 1981", "transition_epoch": "1981-Q1",
                     "onsets": {...}}, ...]
    }
    """
    d = json.load(open(onsets_path))
    obs = d["observed"]
    onsets = sorted(_q(e) for e in obs["onsets"].values())
    notes = []

    if len(onsets) < MIN_ONSETS:
        return SynchronyResult(
            reportable=False,
            reason=f"Only {len(onsets)} onsets. Dispersion over fewer than {MIN_ONSETS} "
                   "crossings is not a distribution.",
            n_onsets=len(onsets),
        )

    obs_disp = _dispersion(onsets)
    baselines = []
    for b in d.get("baselines", []):
        bo = sorted(_q(e) for e in b["onsets"].values())
        if len(bo) < MIN_ONSETS:
            notes.append(f"Baseline '{b['label']}' has {len(bo)} onsets and is excluded.")
            continue
        baselines.append({"label": b["label"], "n_onsets": len(bo),
                          "dispersion_quarters": round(_dispersion(bo), 3)})

    B = len(baselines)
    persistence = _persistence(onsets, _q(obs["transition_epoch"]))

    if B < MIN_BASELINES_FOR_P:
        return SynchronyResult(
            reportable=False,
            reason=(
                f"{B} usable matched baseline transition(s). A rank-based p cannot fall "
                f"below 1/(B+1) = {1/(B+1):.3f}, so no significance claim is available "
                f"at this baseline count however bunched the observed onsets are. "
                f"Score at least {MIN_BASELINES_FOR_P} matched prior transitions before "
                "this layer reports anything."
            ),
            n_onsets=len(onsets),
            observed_dispersion_quarters=round(obs_disp, 3),
            baselines=baselines,
            p_floor_at_this_baseline_count=round(1 / (B + 1), 4),
            persistence=persistence,
            notes=notes + [
                "Observed dispersion and the baselines are shown as descriptive figures. "
                "They are not a test."
            ],
        )

    disps = [b["dispersion_quarters"] for b in baselines]
    rank = 1 + sum(1 for x in disps if x <= obs_disp)   # 1 = most bunched of B+1
    p = rank / (B + 1)
    med = statistics.median(disps)

    return SynchronyResult(
        reportable=True,
        reason="Excess-over-matched-baseline form, per Part IV.",
        n_onsets=len(onsets),
        observed_dispersion_quarters=round(obs_disp, 3),
        baselines=baselines,
        rank_of_observed=rank,
        p_rank_based=round(p, 4),
        p_floor_at_this_baseline_count=round(1 / (B + 1), 4),
        excess_vs_baseline_median=round((med - obs_disp) / med, 4) if med else None,
        persistence=persistence,
        notes=notes + [
            "A positive excess means observed onsets are more bunched than matched "
            "transitions. A non-positive excess means high synchrony is the baseline "
            "rate of regime change and diagnoses nothing."
        ],
    )


if __name__ == "__main__":
    import sys
    print(json.dumps(asdict(run(sys.argv[1] if len(sys.argv) > 1
                                else "register/onsets.json")), indent=2))
