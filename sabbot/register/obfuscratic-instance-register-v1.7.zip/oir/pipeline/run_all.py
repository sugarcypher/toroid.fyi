"""
Run every layer and emit one JSON payload for the renderer.

Refusals are first-class output. A layer that cannot honestly report returns its
reason, and the renderer prints the reason where the number would have been.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import breadth            # noqa: E402
import direction_test     # noqa: E402
import ingest             # noqa: E402
import nullcheck          # noqa: E402  (self-test only; generates its own corpora)
import synchrony          # noqa: E402


def _p(*parts):
    return os.path.join(ROOT, *parts)


def _nullcheck_quiet():
    """Run the four synthetic scenarios without printing them twice."""
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        return nullcheck.main()


def main():
    inst = _p("register", "instances.jsonl")
    rows = [json.loads(l) for l in open(inst) if l.strip()]
    payload = {
        "generated_on": "2026-09-12",
        "rubric_weights": breadth.WEIGHTS,
        "threshold": breadth.THRESHOLD,
        "direction_layer": asdict(direction_test.run(inst)),
        "queue": ingest.queue_status(rows),
        "machine_alteration": ingest.alteration_report(rows),
        "breadth_layer": asdict(breadth.run(_p("register", "architectures.json"),
                                            _p("register", "slate.json"))),
        "synchrony_layer": asdict(synchrony.run(_p("register", "onsets.json"))),
        "pipeline_self_test": _nullcheck_quiet(),
    }
    out = _p("render", "payload.json")
    with open(out, "w") as fh:
        json.dump(payload, fh, indent=2)
    print(json.dumps({k: (v if not isinstance(v, dict) else "...") for k, v in payload.items()}, indent=2))
    print(f"\nwrote {out}")
    return payload


if __name__ == "__main__":
    main()
