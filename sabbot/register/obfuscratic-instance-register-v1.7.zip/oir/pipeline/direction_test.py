"""
Cluster-robust directional test for the Obfuscratic Instance Register.

The claim under test is the one the book concedes at the door: ordinary failure
is symmetric. Under that null, direction across INDEPENDENT DECISION LOCI is as
likely to run one way as the other. Instances inside a locus are dependent by
construction, so the only valid unit is the locus.

Method: collapse each locus to its mean direction, then permute by flipping the
sign of whole loci with probability 1/2. This permits arbitrary dependence within
a locus and is therefore conservative and correct. Exhaustive enumeration when
the locus count is small enough, Monte Carlo otherwise.

The per-instance binomial p is computed and returned LABELLED INVALID, so the
inflation it represents is visible rather than available.
"""

from __future__ import annotations

import itertools
import json
import math
import random
from collections import defaultdict
from dataclasses import dataclass, field, asdict

EXHAUSTIVE_MAX_LOCI = 22          # 2**22 ~ 4.2M sign patterns, tractable
DEFAULT_DRAWS = 200_000

ELIGIBLE_TAGS = {"occurred"}       # Part III: only occurred anchors a realized-outcome claim


@dataclass
class DirectionResult:
    n_instances_in_register: int
    n_instances_eligible: int
    n_loci: int
    effective_n: int                      # loci with nonzero mean
    locus_means: dict
    observed_mean_of_locus_means: float
    p_cluster_two_sided: float
    p_method: str
    p_instance_level_INVALID: float
    p_instance_level_INVALID_log10: float
    inflation_factor_orders_of_magnitude: float | None
    payoff_conjoined_only: dict = field(default_factory=dict)
    exclusions: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)


def _load(path):
    rows = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _eligible(rows):
    """Apply every exclusion the codebook makes non-discretionary."""
    kept, excl = [], defaultdict(int)
    for r in rows:
        prov = r.get("provenance", {})
        if not prov.get("ratified", False):
            excl["unratified_provenance"] += 1
            continue
        if not r.get("frame_id"):
            excl["no_locked_frame"] += 1
            continue
        if r.get("evidence_tag") not in ELIGIBLE_TAGS:
            excl[f"evidence_tag_{r.get('evidence_tag')}"] += 1
            continue
        if r.get("incidence_basis") == "not_yet_established":
            excl["incidence_not_established"] += 1
            continue
        if r.get("direction") == 0:
            excl["direction_zero"] += 1
            continue
        if not r.get("locus_id"):
            excl["no_locus"] += 1
            continue
        kept.append(r)
    return kept, dict(excl)


def _log_binom_pmf(i, n):
    """log of C(n,i) * 0.5**n, in log space so large n does not overflow."""
    return (math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
            - n * math.log(2.0))


def _binomial_two_sided(k, n):
    """
    Exact two-sided binomial p at p=0.5, returned as (p, log10_p).

    Computed in log space because the per-instance test on a large corpus
    produces p-values far below double precision. That it does so is the point:
    this figure is reported labelled invalid, to show what treating dependent
    instances as independent buys.
    """
    if n == 0:
        return 1.0, 0.0
    obs = _log_binom_pmf(k, n)
    terms = [_log_binom_pmf(i, n) for i in range(n + 1)
             if _log_binom_pmf(i, n) <= obs + 1e-12]
    if not terms:
        return 1.0, 0.0
    m = max(terms)
    log_p = m + math.log(sum(math.exp(t - m) for t in terms))
    log10_p = log_p / math.log(10.0)
    try:
        p = math.exp(log_p)
    except OverflowError:
        p = 0.0
    return min(1.0, p), log10_p


def _cluster_signflip_p(means, seed=20260912, draws=None):
    """
    Two-sided p for the mean of locus means under independent locus sign flips.

    Exhaustive enumeration while the locus count is small, vectorised Monte Carlo
    above it. Arbitrary dependence inside a locus is permitted by construction,
    which is what makes this conservative rather than merely robust.
    """
    draws = draws or DEFAULT_DRAWS   # read at call time so callers can lower it
    vals = [m for m in means if m != 0.0]
    k = len(vals)
    if k == 0:
        return 1.0, "degenerate_all_locus_means_zero"
    obs = abs(sum(vals) / k)
    if k <= EXHAUSTIVE_MAX_LOCI:
        hits = total = 0
        for signs in itertools.product((1, -1), repeat=k):
            total += 1
            if abs(sum(s * v for s, v in zip(signs, vals)) / k) >= obs - 1e-12:
                hits += 1
        return hits / total, f"exhaustive_2^{k}"
    try:
        import numpy as np
        rng = np.random.default_rng(seed)
        v = np.asarray(vals, dtype=float)
        hits = 0
        block = max(1, min(draws, 20000))
        done = 0
        while done < draws:
            n = min(block, draws - done)
            signs = rng.integers(0, 2, size=(n, k)) * 2 - 1
            stats = np.abs((signs * v).mean(axis=1))
            hits += int((stats >= obs - 1e-12).sum())
            done += n
        return (hits + 1) / (draws + 1), f"monte_carlo_{draws}_numpy"
    except ImportError:
        rng = random.Random(seed)
        hits = 0
        for _ in range(draws):
            if abs(sum(v if rng.random() < 0.5 else -v for v in vals) / k) >= obs - 1e-12:
                hits += 1
        return (hits + 1) / (draws + 1), f"monte_carlo_{draws}"


def _core(rows):
    by_locus = defaultdict(list)
    for r in rows:
        by_locus[r["locus_id"]].append(float(r["direction"]))
    means = {k: sum(v) / len(v) for k, v in by_locus.items()}
    vals = list(means.values())
    p_cluster, method = _cluster_signflip_p(vals)
    nz = [v for v in vals if v != 0]
    obs_mean = sum(nz) / len(nz) if nz else 0.0
    pos = sum(1 for r in rows if r["direction"] > 0)
    p_inst, log10_p_inst = _binomial_two_sided(max(pos, len(rows) - pos), len(rows))
    return means, obs_mean, p_cluster, method, p_inst, len(nz), log10_p_inst


def run(path, payoff_only_variant=True):
    rows_all = _load(path)
    rows, excl = _eligible(rows_all)
    if not rows:
        return DirectionResult(
            n_instances_in_register=len(rows_all), n_instances_eligible=0, n_loci=0,
            effective_n=0, locus_means={}, observed_mean_of_locus_means=0.0,
            p_cluster_two_sided=1.0, p_method="no_eligible_instances",
            p_instance_level_INVALID=1.0, p_instance_level_INVALID_log10=0.0,
            inflation_factor_orders_of_magnitude=None, exclusions=excl,
            warnings=["No eligible instances. Nothing is reportable."],
        )

    means, obs_mean, p_cluster, method, p_inst, eff_n, log10_p_inst = _core(rows)

    warns = []
    if eff_n < 12:
        warns.append(
            f"effective_n = {eff_n}. Below 12 independent loci the permutation floor "
            f"({2 / 2**eff_n:.4f} two-sided at best) limits what any result can say. "
            "Widen the locus span before deepening coverage."
        )
    if len(rows) / max(eff_n, 1) > 8:
        warns.append(
            f"{len(rows)} instances across {eff_n} nonzero loci "
            f"({len(rows)/eff_n:.1f} per locus). Item count is running far ahead of "
            "independent loci; additional coding in represented loci adds no power."
        )
    neg = sum(1 for r in rows if r["direction"] < 0)
    if neg == 0 and len(rows) >= 40:
        warns.append(
            f"Zero negative codings across {len(rows)} eligible instances. Either the "
            "world is one-directional or the frame was not content-blind. The register "
            "cannot distinguish these from the inside; have a second coder re-run a "
            "blind subset before publishing."
        )

    payoff = {}
    if payoff_only_variant:
        sub = [r for r in rows if r.get("payoff_conjunction") is True]
        if sub:
            m2, om2, pc2, meth2, pi2, en2, lg2 = _core(sub)
            payoff = {
                "n_instances": len(sub), "effective_n": en2,
                "observed_mean_of_locus_means": round(om2, 4),
                "p_cluster_two_sided": pc2, "p_method": meth2,
            }
        else:
            payoff = {"n_instances": 0, "note": "No payoff-conjoined instances to test."}

    return DirectionResult(
        n_instances_in_register=len(rows_all),
        n_instances_eligible=len(rows),
        n_loci=len(means),
        effective_n=eff_n,
        locus_means={k: round(v, 4) for k, v in sorted(means.items())},
        observed_mean_of_locus_means=round(obs_mean, 4),
        p_cluster_two_sided=p_cluster,
        p_method=method,
        p_instance_level_INVALID=p_inst,
        p_instance_level_INVALID_log10=round(log10_p_inst, 2),
        inflation_factor_orders_of_magnitude=(
            round(math.log10(p_cluster) - log10_p_inst, 2)
            if p_cluster > 0 else None),
        payoff_conjoined_only=payoff,
        exclusions=excl,
        warnings=warns,
    )


if __name__ == "__main__":
    import sys
    res = run(sys.argv[1] if len(sys.argv) > 1 else "register/instances.jsonl")
    print(json.dumps(asdict(res), indent=2))
