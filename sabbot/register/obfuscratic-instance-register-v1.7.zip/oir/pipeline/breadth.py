"""
Breadth-velocity with a fixed, pre-registered denominator.

Part IV: "Let the frame grow by adding architectures because they already score
high, and the count rises as a pure artifact of where you pointed; the metric
then measures the analyst's attention, not the world."

So this module does not compute breadth velocity on request. It first checks the
slate scored at each epoch against the pre-registered slate, and returns a FRAME
VIOLATION rather than a number when the denominator moved.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict

WEIGHTS = {"S1": 0.25, "S2": 0.20, "S3": 0.15, "S4": 0.10, "S5": 0.30}
BANDS = [(0, 30, "genuine"), (30, 70, "mixed"), (70, 85, "high_asymmetry"),
         (85, 100.0001, "extreme_asymmetry")]
THRESHOLD = 70.0


def composite(e):
    """
    Recompute from dimensions where they exist. Where only a published composite
    was transcribed, use it and mark the epoch as un-auditable rather than
    back-fitting dimensions to match it.
    """
    if all(k in e and e[k] is not None for k in WEIGHTS):
        return round(sum(WEIGHTS[k] * float(e[k]) for k in WEIGHTS), 2), True
    if e.get("composite_only") is not None:
        return float(e["composite_only"]), False
    return None, False


def band(c):
    for lo, hi, name in BANDS:
        if lo <= c < hi:
            return name
    return "out_of_range"


@dataclass
class BreadthResult:
    frame_valid: bool
    violation: str | None
    slate_id: str | None
    denominator: int | None
    epochs: list = field(default_factory=list)
    breadth_velocity_per_quarter: list = field(default_factory=list)
    notes: list = field(default_factory=list)


def _q(epoch):
    y, q = epoch.split("-Q")
    return int(y) * 4 + (int(q) - 1)


def run(arch_path, slate_path):
    slate = json.load(open(slate_path))
    archs = json.load(open(arch_path))
    registered = set(slate["members"])
    notes = []

    scored = {a["architecture_id"] for a in archs}
    intruders = sorted(scored - registered)
    if intruders:
        return BreadthResult(
            frame_valid=False,
            violation=(
                "FRAME VIOLATION. Architectures scored but absent from the "
                f"pre-registered slate '{slate['slate_id']}': {intruders}. "
                "Breadth velocity over a denominator that grew with the numerator "
                "measures the analyst's attention. No number is returned. Either add "
                "these to the slate with a locked prior band prediction and rescore the "
                "whole slate, or drop them from the breadth layer."
            ),
            slate_id=slate["slate_id"], denominator=None,
        )

    unpredicted = [a["architecture_id"] for a in archs
                   if not a.get("slate_membership", {}).get("predicted_band")]
    if unpredicted:
        return BreadthResult(
            frame_valid=False,
            violation=(
                "FRAME VIOLATION. No locked prior band prediction for: "
                f"{unpredicted}. Part VI requires the prediction before the scoring; "
                "matching a prediction to an outcome afterwards destroys what the "
                "controls were worth."
            ),
            slate_id=slate["slate_id"], denominator=None,
        )

    missing = sorted(registered - scored)
    if missing:
        notes.append(
            f"{len(missing)} slate members are unscored: {missing}. They remain in the "
            "denominator, which is correct and which lowers the reported proportion. "
            "Removing them would inflate breadth."
        )

    all_epochs = sorted({e["epoch"] for a in archs for e in a["epochs"]}, key=_q)
    rows = []
    for ep in all_epochs:
        above, counted, unauditable = 0, 0, 0
        for a in archs:
            hit = next((e for e in a["epochs"] if e["epoch"] == ep), None)
            if hit is None:
                continue
            c, auditable = composite(hit)
            if c is None:
                continue
            counted += 1
            if not auditable:
                unauditable += 1
            if c >= THRESHOLD:
                above += 1
        rows.append({
            "epoch": ep,
            "slate_denominator": len(registered),
            "scored_this_epoch": counted,
            "above_threshold": above,
            "proportion_of_slate": round(above / len(registered), 4),
            "composite_only_unauditable": unauditable,
        })

    vel = []
    for a, b in zip(rows, rows[1:]):
        dq = _q(b["epoch"]) - _q(a["epoch"])
        if dq <= 0:
            continue
        vel.append({
            "from": a["epoch"], "to": b["epoch"], "quarters": dq,
            "architectures_per_quarter":
                round((b["above_threshold"] - a["above_threshold"]) / dq, 3),
        })

    notes.append(
        "Breadth velocity is only interpretable against this fixed denominator of "
        f"{len(registered)}. Report the proportion beside the count; the count alone "
        "invites the artifact the guard exists to prevent."
    )
    return BreadthResult(True, None, slate["slate_id"], len(registered), rows, vel, notes)


if __name__ == "__main__":
    import sys
    a = sys.argv[1] if len(sys.argv) > 1 else "data/demo/architectures.demo.json"
    s = sys.argv[2] if len(sys.argv) > 2 else "data/demo/slate.demo.json"
    print(json.dumps(asdict(run(a, s)), indent=2))
